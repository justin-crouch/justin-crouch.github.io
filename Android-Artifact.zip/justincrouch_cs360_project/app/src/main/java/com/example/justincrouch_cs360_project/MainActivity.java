package com.example.justincrouch_cs360_project;

import static android.Manifest.permission.SEND_SMS;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

/**
 * MainActivity
 *
 * Display inventory items on the screen, prompt for SMS notifications,
 * allow user to add a new item, and allow user to logout of app
 */
public class MainActivity extends AppCompatActivity {

    /**
     * onCreate
     *
     * Display inventory items on the screen, prompt for SMS notifications,
     * allow user to add a new item, and allow user to logout of app
     *
     * @param savedInstanceState If the activity is being re-initialized after
     *     previously being shut down then this Bundle contains the data it most
     *     recently supplied in {@link #onSaveInstanceState}.  <b><i>Note: Otherwise it is null.</i></b>
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Initialize activity
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Get logged in user's ID
        long userID = getIntent().getLongExtra("userID", -1L);

        // Load inventory database
        InventoryDatabase inventoryDBHelper = new InventoryDatabase(getApplicationContext());

        // Grab references to required views in the main layout
        RecyclerView inventoryRecyclerView = findViewById(R.id.RVInventoryList);
        ImageButton menuButton = findViewById(R.id.buttonMenu);
        Button addItemButton = findViewById(R.id.buttonAddItemFOB);
        Button enableSMSButton = findViewById(R.id.buttonEnableSMS);
        Button logoutButton = findViewById(R.id.buttonLogout);
        LinearLayout menuViewGroup = findViewById(R.id.layoutMenu);

        // Initialize adapter for loading items from the database on the main layout
        // Load adapter onto the recycler view
        // Display items as a linear list
        InventoryRecyclerViewAdapter adapter = new InventoryRecyclerViewAdapter(this, inventoryDBHelper, userID);
        inventoryRecyclerView.setAdapter(adapter);
        inventoryRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Display 'Enable SMS' button if SEND_SMS permission is not granted
        if (ActivityCompat.checkSelfPermission(this, SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            enableSMSButton.setVisibility(View.VISIBLE);
        } else {
            enableSMSButton.setVisibility(View.GONE);
        }

        // Navigate to the new item activity if the FAB is pressed
        addItemButton.setOnClickListener(v -> {
            Intent addItemActivityIntent = new Intent(MainActivity.this, NewItemActivity.class);
            addItemActivityIntent.putExtra("userID", userID);
            startActivity(addItemActivityIntent);
        });

        // Toggle visibility of menu view on the main layout
        menuButton.setOnClickListener(v -> {
            if(menuViewGroup.getVisibility() == View.GONE) {
                menuViewGroup.setVisibility(View.VISIBLE);
            } else {
                menuViewGroup.setVisibility(View.GONE);
            }
        });

        // Navigate to login activity when user wants to log out
        logoutButton.setOnClickListener(v -> {
            Intent loginctivityIntent = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(loginctivityIntent);
        });

        // Request user to send sms notifications
        enableSMSButton.setOnClickListener(v -> {
            ActivityCompat.requestPermissions(this, new String[] {SEND_SMS}, PackageManager.PERMISSION_GRANTED);
        });
    }
}