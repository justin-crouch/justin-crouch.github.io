package com.example.justincrouch_cs360_project;

import static com.example.justincrouch_cs360_project.R.color.error_text;
import static com.example.justincrouch_cs360_project.R.color.success_text;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

/**
 * LoginActivity
 *
 * Default activity to handle logging user in to app
 */
public class LoginActivity extends AppCompatActivity {

    // User database class helper
    private UserDatabase userDBHelper;

    /**
     * onCreate
     *
     * Load login screen and setup button callbacks
     *
     * @param savedInstanceState If the activity is being re-initialized after
     *     previously being shut down then this Bundle contains the data it most
     *     recently supplied in {@link #onSaveInstanceState}.  <b><i>Note: Otherwise it is null.</i></b>
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Initialize activity and load login screen
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize user database
        // Creates empty user database table if database does not exist
        userDBHelper = new UserDatabase(getApplicationContext());

        // Grab references to various views on login screen
        final TextView textLoginMessage = findViewById(R.id.textLoginMessage);
        final EditText editUsername = findViewById(R.id.editUsername);
        final EditText editPassword = findViewById(R.id.editPassword);
        final Button buttonLogin = findViewById(R.id.buttonLogin);
        final Button buttonRegister = findViewById(R.id.buttonRegister);

        // Check supplied username and password fields
        // Switch to main activity if login details are valid
        buttonLogin.setOnClickListener(v -> {

            // Get username and password fields
            String inputUsername = editUsername.getText().toString();
            String inputPassword = editPassword.getText().toString();

            // Go to main activity if username and password are in database
            // Send logged in user's ID to main activity
            long userID = userDBHelper.getLoginID(inputUsername, inputPassword);
            if(userID != -1L) {
                textLoginMessage.setVisibility(View.INVISIBLE);

                Intent mainActivityIntent = new Intent(LoginActivity.this, MainActivity.class);
                mainActivityIntent.putExtra("userID", userID);
                startActivity(mainActivityIntent);

            // Present login error message if login details are not valid
            } else {
                textLoginMessage.setText(R.string.invalid_login);
                textLoginMessage.setTextColor(getResources().getColor(error_text));
                textLoginMessage.setVisibility(View.VISIBLE);
            }

            // Reset password field
            editPassword.setText("");
        });

        // Create new user account with supplied username and password
        // if user does not exist
        buttonRegister.setOnClickListener(v -> {

            // Get username and password fields
            String inputUsername = editUsername.getText().toString();
            String inputPassword = editPassword.getText().toString();
            long newUserID = userDBHelper.addUser(inputUsername, inputPassword);

            // Present registration error message if user could not be created
            if(newUserID < 0) {
                textLoginMessage.setText(R.string.registration_fail);
                textLoginMessage.setTextColor(getResources().getColor(error_text));

            // Present registration success message if user was created
            } else {
                textLoginMessage.setText(R.string.registration_success);
                textLoginMessage.setTextColor(getResources().getColor(success_text));
            }

            // Show registration message
            textLoginMessage.setVisibility(View.VISIBLE);

            // Reset password field
            editPassword.setText("");
        });
    }
}