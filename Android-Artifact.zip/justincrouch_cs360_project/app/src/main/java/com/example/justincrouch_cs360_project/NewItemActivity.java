package com.example.justincrouch_cs360_project;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

/**
 * NewItemActivity
 *
 * Activity to handle adding a new item in the inventory database
 */
public class NewItemActivity extends AppCompatActivity {

    /**
     * onCreate
     *
     * Setup various button events in the new item layout
     *
     * @param savedInstanceState If the activity is being re-initialized after
     *     previously being shut down then this Bundle contains the data it most
     *     recently supplied in {@link #onSaveInstanceState}.  <b><i>Note: Otherwise it is null.</i></b>
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Initialize activity
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_item);

        // Get logged in user's ID
        long userID = getIntent().getLongExtra("userID", -1L);

        // Load inventory database
        InventoryDatabase inventoryDBHelper = new InventoryDatabase(getApplicationContext());

        // Get references to needed views in the new item layout
        TextView emptyNameMsgView = findViewById(R.id.textNameEmptyMsg);
        TextView emptyAmountMsgView = findViewById(R.id.textAmountEmptyMsg);
        EditText newItemNameView = findViewById(R.id.editNewItemName);
        EditText newItemAmount = findViewById(R.id.editNewItemAmount);
        Button addNewItem = findViewById(R.id.buttonAddNewItem);
        Button cancelNewItem = findViewById(R.id.buttonCancelNewItem);

        // Handle adding a new item to the database
        addNewItem.setOnClickListener(v -> {
            // Grab user-supplied item name and initial amount
            String itemName = newItemNameView.getText().toString();
            String itemAmountStr = newItemAmount.getText().toString();

            // Display error message if item name entry is empty
            if(itemName.isEmpty()) {
                emptyNameMsgView.setVisibility(TextView.VISIBLE);
            } else {
                emptyNameMsgView.setVisibility(TextView.INVISIBLE);
            }

            // Display error message if item amount entry is empty
            if(itemAmountStr.isEmpty()) {
                emptyAmountMsgView.setVisibility(TextView.VISIBLE);
                return;
            } else {
                emptyAmountMsgView.setVisibility(TextView.INVISIBLE);
            }

            // Parse item amount entry to an integer
            int itemAmount = 0;
            try {
                itemAmount = Integer.parseInt(itemAmountStr);
            } catch (NumberFormatException e) {
                //throw new RuntimeException(e);
            }

            // Add new item to database given user-supplied data
            inventoryDBHelper.addItem(itemName, itemAmount, userID);

            // Navigate back to main activity
            Intent mainActivityIntent = new Intent(NewItemActivity.this, MainActivity.class);
            mainActivityIntent.putExtra("userID", userID);
            startActivity(mainActivityIntent);
        });

        // Stop adding a new item and navigate back to main activity
        cancelNewItem.setOnClickListener(v -> {
            Intent mainActivityIntent = new Intent(NewItemActivity.this, MainActivity.class);
            mainActivityIntent.putExtra("userID", userID);
            startActivity(mainActivityIntent);
        });
    }
}