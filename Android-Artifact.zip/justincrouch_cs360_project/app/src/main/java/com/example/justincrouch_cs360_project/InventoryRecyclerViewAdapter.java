package com.example.justincrouch_cs360_project;

import static android.Manifest.permission.SEND_SMS;

import android.content.Context;
import android.content.pm.PackageManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * InventoryRecyclerViewAdapter
 *
 * Handle populating the item list on the main activity
 */
public class InventoryRecyclerViewAdapter extends RecyclerView.Adapter<InventoryRecyclerViewAdapter.MyViewHolder> {

    // Store reference to calling context
    private Context context;

    // Store reference to inventory database connection
    private InventoryDatabase inventoryDBHelper;

    // Store list of item objects populated by inventory database
    private List<InventoryDatabase.Item> inventoryItems;

    // Store last item view clicked
    private ConstraintLayout previousClickedItemSummary;

    // Tag for logging sms notifications
    private final String TAG = "SMS_NOTIFICATION";

    /**
     * InventoryRecyclerViewAdapter
     *
     * Constructor that grabs reference to calling context and inventory database connection
     *
     * @param context
     * @param inventoryDBHelper Reference to inventory database connection
     * @param userID ID of some user in UserDatabase
     */
    public InventoryRecyclerViewAdapter(Context context, InventoryDatabase inventoryDBHelper, long userID) {
        this.context = context;
        this.inventoryDBHelper = inventoryDBHelper;
        this.inventoryItems = inventoryDBHelper.getItems(userID);
    }

    /**
     * onCreateViewHolder
     *
     * Inflate a new item view onto the recycler view
     *
     * @param parent   The ViewGroup into which the new View will be added after it is bound to
     *                 an adapter position.
     * @param viewType The view type of the new View.
     * @return A new InventoryRecyclerViewAdapter.MyViewHolder with references to a new item view
     */
    @NonNull
    @Override
    public InventoryRecyclerViewAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate layout to present rows
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.activity_item, parent, false);

        // Return initialized MyViewHolder
        return new InventoryRecyclerViewAdapter.MyViewHolder(view);
    }

    /**
     * onBindViewHolder
     *
     * Populate each item view's components with data from its respective item object data
     *
     * @param holder   The ViewHolder which should be updated to represent the contents of the
     *                 item at the given position in the data set.
     * @param position The position of the item within the adapter's data set.
     */
    @Override
    public void onBindViewHolder(@NonNull InventoryRecyclerViewAdapter.MyViewHolder holder, int position) {
        // Get corresponding item object from inventory items list
        InventoryDatabase.Item item = inventoryItems.get(position);

        // Populate item view's name and hide item update menu
        holder.itemNameView.setText(item.getName());
        holder.itemUpdateLayout.setVisibility(View.GONE);

        // Populate item view's amount
        setItemAmountView(holder.itemAmountView, item.getAmount());

        // Show or hide item update view when item view is clicked
        holder.itemSummaryLayout.setOnClickListener(v -> {
            // Hide previously clicked item view's update view
            // Set previously clicked item view to this item view
            if(previousClickedItemSummary != null && previousClickedItemSummary != holder.itemUpdateLayout) {
                previousClickedItemSummary.setVisibility(View.GONE);
            }
            previousClickedItemSummary = holder.itemUpdateLayout;

            // Show or hide item update view when item view is clicked
            if(holder.itemUpdateLayout.getVisibility() == View.GONE) {
                holder.itemUpdateLayout.setVisibility(View.VISIBLE);
            } else {
                holder.itemUpdateLayout.setVisibility(View.GONE);
            }
        });

        // Add wanted amount to corresponding item in database
        holder.itemAddAmountButton.setOnClickListener(v -> {
            // Get wanted amount to change the item amount by from user input
            // User input must be parsed to an integer
            int adjustAmount = 0;
            try {
                adjustAmount = Integer.parseInt(holder.itemAdjustAmount.getText().toString());
            } catch (NumberFormatException e) {
                //throw new RuntimeException(e);
            }

            // Get item's current amount
            // Add current amount to adjustment to get item's new amount
            int currentItemAmount = item.getAmount();
            int newAmount = adjustAmount + currentItemAmount;

            // If new amount is different from current amount
            // Update item in database and in list cache
            if(newAmount != currentItemAmount) {
                boolean updatedNumber = inventoryDBHelper.updateItemAmount(item.getId(), newAmount);
                if(updatedNumber) {
                    // Update item view amount
                    setItemAmountView(holder.itemAmountView, newAmount);
                    item.setAmount(newAmount);
                }
            }
        });

        // Subtract wanted amount to corresponding item in database
        holder.itemSubtractAmountButton.setOnClickListener(v -> {
            // Get wanted amount to change the item amount by from user input
            // User input must be parsed to an integer
            int adjustAmount = 0;
            try {
                adjustAmount = Integer.parseInt(holder.itemAdjustAmount.getText().toString());
            } catch (NumberFormatException e) {
                //throw new RuntimeException(e);
            }

            // Get item's current amount
            // Subtract adjust amount from current amount to get item's new amount
            // Do not let new amount become negative
            int currentItemAmount = item.getAmount();
            int newAmount = Math.max(currentItemAmount - adjustAmount, 0);

            // If new amount is different from current amount
            // Update item in database and in list cache
            if(newAmount != currentItemAmount) {
                boolean updatedNumber = inventoryDBHelper.updateItemAmount(item.getId(), newAmount);
                if(updatedNumber) {
                    // Update item view amount
                    setItemAmountView(holder.itemAmountView, newAmount);
                    item.setAmount(newAmount);
                }
            }

            // Send user a SMS notification if app has permission
            if(newAmount == 0 && ActivityCompat.checkSelfPermission(context, SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                Log.i(TAG, "Item [" + item.getName() + "] Is Empty");
            }
        });

        // Remove item from database and list cache
        holder.itemRemoveButton.setOnClickListener(v -> {
            inventoryDBHelper.deleteItem(item.getId());
            inventoryItems.remove(position);

            // Update recycler view to show changes
            notifyDataSetChanged();
        });
    }

    /**
     * getItemCount
     *
     * Returns how many items total to be displayed
     *
     * @return Number of items in item list cache
     */
    @Override
    public int getItemCount() {
        // Return how many items are in inventory
        return inventoryItems.size();
    }

    /**
     * MyViewHolder
     *
     * Inner class to store references to an item's views
     */
    public static class MyViewHolder extends RecyclerView.ViewHolder {

        // Store references to views in item layout
        public TextView itemNameView;
        public TextView itemAmountView;
        public ConstraintLayout itemUpdateLayout;
        public ConstraintLayout itemSummaryLayout;
        public Button itemAddAmountButton;
        public Button itemSubtractAmountButton;
        public ImageButton itemRemoveButton;
        public EditText itemAdjustAmount;

        /**
         * MyViewHolder
         *
         * Constructor to grab references to an item view's views
         *
         * @param itemView The new item view that was created
         */
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            // Grab references to the item view's views
            itemNameView = itemView.findViewById(R.id.textItemName);
            itemAmountView = itemView.findViewById(R.id.textItemAmount);
            itemUpdateLayout = itemView.findViewById(R.id.layoutUpdateItem);
            itemSummaryLayout = itemView.findViewById(R.id.layoutItemSummary);
            itemAddAmountButton = itemView.findViewById(R.id.buttonAddAmount);
            itemSubtractAmountButton = itemView.findViewById(R.id.buttonSubtractAmount);
            itemRemoveButton = itemView.findViewById(R.id.buttonRemoveItem);
            itemAdjustAmount = itemView.findViewById(R.id.editAdjustAmount);
        }
    }

    /**
     * setItemAmountView
     *
     * Helper function to format the item view's amount
     *
     * @param amountView View referencing an item view's amount
     * @param amount The amount to set the amount view to
     */
    private static void setItemAmountView(TextView amountView, int amount) {
        // Display '999+' when amount is above 999
        if(amount > 999) {
            amountView.setText("999+");

        // Display given amount on amount view
        } else {
            amountView.setText(String.valueOf(amount));
        }
    }
}
