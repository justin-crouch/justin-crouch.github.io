package com.example.justincrouch_cs360_project;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * InventoryDatabase
 *
 * Handle CRUD operations on the inventory database
 */
public class InventoryDatabase extends SQLiteOpenHelper {

    // Define name of the database to use and current
    // version of the database schema
    private static final String DATABASE_NAME = "inventory.db";
    private static final int VERSION = 5;

    /**
     * InventoryDatabase
     *
     * Constructor; Initialize the SQLite file if version is outdated
     * or file does not exist
     *
     * @param context
     */
    public InventoryDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    /**
     * InventoryTable
     *
     * Inner class that defines database schema
     */
    private static final class InventoryTable {
        private static final String TABLE = "inventory";
        private static final String COL_ID = "_id";
        private static final String COL_NAME = "item_name";
        private static final String COL_AMOUNT = "item_amount";
        private static final String COL_OWNER_ID = "owner_id";
    }

    /**
     * Item
     *
     * Inner class to represent an Item object from the database
     */
    public static class Item {
        private long id;
        private String name;
        private int amount;

        /**
         * Item
         *
         * Constructor for initializing an item object
         *
         * @param id The item ID in the database
         * @param name The item name in the database
         * @param amount The item amount in the database
         */
        public Item(long id, String name, int amount) {
            this.id = id;
            this.name = name;
            this.amount = amount;
        }

        // Necessary getters and setters for accessing/updating item objects
        public int getAmount() {
            return amount;
        }

        public void setAmount(int amount) {
            this.amount = amount;
        }

        public String getName() {
            return name;
        }

        public long getId() {
            return id;
        }
    }

    /**
     * onCreate
     *
     * Creates the database table if database version is
     * outdated or database does not exist
     *
     * @param db The database.
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + InventoryTable.TABLE + " (" +
                InventoryTable.COL_ID + " integer primary key autoincrement, " +
                InventoryTable.COL_NAME + " text not null, " +
                InventoryTable.COL_AMOUNT + " integer not null, " +
                InventoryTable.COL_OWNER_ID + " integer not null, " +
                "foreign key (" + InventoryTable.COL_OWNER_ID + ") references " + UserDatabase.UserTable.TABLE + " (" + UserDatabase.UserTable.COL_ID + ") on delete cascade)");
    }

    /**
     * onUpgrade
     *
     * Removes outdated database table and creates
     * new table from scratch
     *
     * @param db The database.
     * @param oldVersion The old database version.
     * @param newVersion The new database version.
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + InventoryTable.TABLE);
        onCreate(db);
    }

    /**
     * addItem
     *
     * Add a new item to the database for a specific if name
     * and amount are valid
     *
     * @param name User-supplied name for new item; Cannot be empty
     * @param amount User-supplied initial amount; Cannot be negative
     * @param ownerID ID of some user in UserDatabase
     * @return New item ID if successful; -1L elsewise
     */
    public long addItem(String name, int amount, long ownerID) {

        // Return -1L if supplied name is an empty string
        if(name.isEmpty()) {
            return -1L;
        }

        // Return -1L if initial amount is negative
        if(amount < 0) {
            return -1L;
        }

        // Open database file for writing
        SQLiteDatabase inventoryDBWritable = getWritableDatabase();

        // Initialize a new entry for inserting into database
        ContentValues values = new ContentValues();
        values.put(InventoryTable.COL_NAME, name);
        values.put(InventoryTable.COL_AMOUNT, amount);
        values.put(InventoryTable.COL_OWNER_ID, ownerID);

        // Insert into database
        // Return new item ID if successful; else return -1L
        return inventoryDBWritable.insert(InventoryTable.TABLE, null, values);
    }

    /**
     * getItems
     *
     * Return all items in the database from a specific user
     *
     * @param userID ID of some user in UserDatabase
     * @return List of item objects
     */
    public List<Item> getItems(long userID) {
        // Initialize array list to hold inventory item information
        ArrayList<Item> items = new ArrayList<Item>();

        // Open database file for reading
        SQLiteDatabase inventoryDBReadable = getReadableDatabase();

        // Grab only the column IDs when searching the database
        String[] columnsToReturn = {
                InventoryTable.COL_ID,
                InventoryTable.COL_NAME,
                InventoryTable.COL_AMOUNT
        };

        // Query for items for a given user
        String sqlWhereQuery = InventoryTable.COL_OWNER_ID + " = ?";
        String[] sqlWhereArgs = {
                String.valueOf(userID)
        };

        // Get database cursor from querying database
        Cursor cursor = inventoryDBReadable.query(
                InventoryTable.TABLE,
                columnsToReturn,
                sqlWhereQuery,
                sqlWhereArgs,
                null,
                null,
                null
        );

        // Loop through cursor and initialize item objects
        while(cursor.moveToNext()) {

            // Get current item's ID, name, and amount in the database
            long itemID = cursor.getLong(cursor.getColumnIndexOrThrow(InventoryTable.COL_ID));
            String itemName = cursor.getString(cursor.getColumnIndexOrThrow(InventoryTable.COL_NAME));
            int itemAmount = cursor.getInt(cursor.getColumnIndexOrThrow(InventoryTable.COL_AMOUNT));

            // Initialize a new item object and insert into a list
            items.add(new Item(itemID, itemName, itemAmount));
        }

        // Close the cursor to free resources
        cursor.close();

        // Return the list of items
        return items;
    }

    /**
     * updateItemAmount
     *
     * Update the amount of an item given its item ID
     *
     * @param id ID of the item in the database
     * @param amount New amount of the item; must not be negative
     * @return True if update was successful; false otherwise
     */
    public boolean updateItemAmount(long id, int amount) {

        // Return false if amount is negative
        if(amount < 0) {
            return false;
        }

        // Open database file for writing
        SQLiteDatabase inventoryDBWritable = getWritableDatabase();

        // Initialize values to change in database
        ContentValues values = new ContentValues();
        values.put(InventoryTable.COL_AMOUNT, amount);

        // Select specific item given an id
        String sqlWhereQuery = InventoryTable.COL_ID + " = ?";
        String[] sqlWhereArgs = {
                Long.toString(id)
        };

        // Update item in database
        // Return if item amount was updated
        int updated = inventoryDBWritable.update(InventoryTable.TABLE, values, sqlWhereQuery, sqlWhereArgs);
        return updated > 0;
    }

    /**
     * deleteItem
     *
     * Delete item from database given its item ID
     *
     * @param id ID of item in database
     * @return True if item was deleted; false otherwise
     */
    public boolean deleteItem(long id) {
        // Open database file for writing
        SQLiteDatabase inventoryDBWritable = getWritableDatabase();

        // Select specific item given an id
        String sqlWhereQuery = InventoryTable.COL_ID + " = ?";
        String[] sqlWhereArgs = {
                Long.toString(id)
        };

        // Delete item in database
        // Return true if item was deleted; false otherwise
        int itemsDeleted = inventoryDBWritable.delete(InventoryTable.TABLE, sqlWhereQuery, sqlWhereArgs);
        return itemsDeleted > 0;
    }
}
