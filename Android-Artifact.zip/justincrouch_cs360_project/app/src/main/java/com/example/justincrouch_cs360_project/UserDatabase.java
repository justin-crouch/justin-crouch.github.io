package com.example.justincrouch_cs360_project;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * UserDatabase
 *
 * Handle CRUD operations on the user database
 */
public class UserDatabase extends SQLiteOpenHelper {

    // Define name of the database to use and current
    // version of the database schema
    private static final String DATABASE_NAME = "users.db";
    private static final int VERSION = 5;

    /**
     * UserDatabase
     *
     * Constructor; Initialize the SQLite file if version is outdated
     * or file does not exist
     *
     * @param context
     */
    public UserDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    /**
     * UserTable
     *
     * Inner class that defines database schema
     */
    public static final class UserTable {
        public static final String TABLE = "users";
        public static final String COL_ID = "_id";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
    }

    /**
     * onCreate
     *
     * Creates the database table if database version is
     * outdated or database does not exist
     *
     * @param db The database.
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + UserTable.TABLE + " (" +
                UserTable.COL_ID + " integer primary key autoincrement, " +
                UserTable.COL_USERNAME + " text unique not null, " +
                UserTable.COL_PASSWORD + " text not null)");
    }

    /**
     * onUpgrade
     *
     * Removes outdated database table and creates
     * new table from scratch
     *
     * @param db The database.
     * @param oldVersion The old database version.
     * @param newVersion The new database version.
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + UserTable.TABLE);
        onCreate(db);
    }

    /**
     * addUser
     *
     * Add a new user to the database if username
     * and password are valid
     *
     * @param username User-supplied username; Must be unique; Will
     *                 be transformed to all-lowercase
     * @param password User-supplied password; Will be hashed using
     *                 SHA256 algorithm before storing in database
     * @return New user ID if successful; -1L if username
     *         is already in use or username/password are empty strings
     */
    public long addUser(String username, String password) {

        // Return -1L if supplied arguments are empty strings
        if(username.isEmpty() || password.isEmpty()) {
            return -1L;
        }

        // Open database file for writing
        SQLiteDatabase userDBWritable = getWritableDatabase();

        // Initialize a new entry for inserting into database
        // Transform username to all lowercase characters
        // Generate SHA256 hash of password to insert into database
        ContentValues values = new ContentValues();
        values.put(UserTable.COL_USERNAME, username.toLowerCase());
        values.put(UserTable.COL_PASSWORD, hashPassword(password));

        // Insert into database
        // Return new user ID if successful; else return -1L
        return userDBWritable.insert(UserTable.TABLE, null, values);
    }

    /**
     * getLoginID
     *
     * Check if supplied username and password are found
     * in database
     *
     * @param username User-supplied username; Must be unique; Will
     *                 be transformed to all-lowercase
     * @param password User-supplied password; Will be hashed using
     *                 SHA256 algorithm before searching in database
     * @return User ID corresponding to credentials if login details are found; -1 otherwise
     */
    public long getLoginID(String username, String password) {

        // Return -1L if supplied arguments are empty strings
        if(username.isEmpty() || password.isEmpty()) {
            return -1L;
        }

        // Open database file for reading
        SQLiteDatabase userDBReadable = getReadableDatabase();

        // Grab only the column IDs when searching the database
        String[] columnsToReturn = {
                UserTable.COL_ID
        };

        // Define the SQL WHERE query to find rows with specified
        // username and password
        String sqlWhereQuery = UserTable.COL_USERNAME + " = ? and " +
                UserTable.COL_PASSWORD + " = ?";
        String[] sqlWhereArgs = {
                username.toLowerCase(),
                hashPassword(password)
        };

        // Get database cursor from querying database
        Cursor cursor = userDBReadable.query(
                UserTable.TABLE,
                columnsToReturn,
                sqlWhereQuery,
                sqlWhereArgs,
                null,
                null,
                null
        );

        // Get number of rows returned from query
        long userID = -1L;
        while(cursor.moveToNext()) {
            userID = cursor.getLong(cursor.getColumnIndexOrThrow(UserTable.COL_ID));
        }
        cursor.close();

        // Return user ID if user is found
        // with transformed username and password; -1L otherwise
        return userID;
    }

    /**
     * hashPassword
     *
     * Helper method to generate SHA256 hash of supplied password
     * for securely storing user password
     *
     * @param rawPassword User-supplied password
     * @return SHA256 hash string of raw password
     */
    private static String hashPassword(String rawPassword) {

        // Create SHA256 message digest for hashing
        MessageDigest sha256 = null;
        try {
            sha256 = MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }

        // Hash user-supplied password
        byte[] passwordHashBytes = sha256.digest(rawPassword.getBytes(StandardCharsets.UTF_8));

        // Return string of hashed password
        return new String(passwordHashBytes, StandardCharsets.UTF_8);
    }
}
